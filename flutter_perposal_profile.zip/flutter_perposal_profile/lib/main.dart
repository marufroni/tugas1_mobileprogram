import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Personal Profile',
      theme: ThemeData(
        fontFamily: 'Lobster', 
        primarySwatch: Colors.teal,
      ),
      home: CVScreen(),
    );
  }
}

class CVScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Personal Profile'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color.fromRGBO(127, 143, 126, 1.0),
              const Color.fromRGBO(237, 233, 231, 1),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage('assets/images/profile.jpg'),
                  ),
                ),
                SizedBox(height: 16),
                Center(
                  child: Text(
                    'Maruf Syahroni',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(height: 8),
                Center(
                  child: Text(
                    'Mahasiswa Informatika - UNUGHA Cilacap',
                    style: TextStyle(fontSize: 18, color: const Color.fromARGB(255, 56, 56, 56)),
                  ),
                ),
                SizedBox(height: 16),
                Divider(),
                SizedBox(height: 16),
                Text(
                  'Informasi Pribadi',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                ListTile(
                  leading: Icon(Icons.email),
                  title: Text('Email'),
                  subtitle: Text('dmnyusron@gmail.com'),
                ),
                ListTile(
                  leading: Icon(Icons.phone),
                  title: Text('Telepon'),
                  subtitle: Text('0888-5961-012'),
                ),
                ListTile(
                  leading: Icon(Icons.location_on),
                  title: Text('Alamat'),
                  subtitle: Text('Desa Pekuncen, Kecamatan Kroya, Kabupaten Cilacap, Indonesia'),
                ),
                SizedBox(height: 16),
                Text(
                  'Kemampuan',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Card(
                  child: ListTile(
                    leading: Icon(Icons.code),
                    title: Text('Pemrograman'),
                    subtitle: Text('Javascript, PHP, Flutter'),
                  ),
                ),
                Card(
                  child: ListTile(
                    leading: Icon(Icons.design_services),
                    title: Text('Desain UI'),
                    subtitle: Text('Tailwind, React'),
                  ),
                ),
                Card(
                  child: ListTile(
                    leading: Icon(Icons.language),
                    title: Text('Bahasa'),
                    subtitle: Text('Bahasa Indonesia, English'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
