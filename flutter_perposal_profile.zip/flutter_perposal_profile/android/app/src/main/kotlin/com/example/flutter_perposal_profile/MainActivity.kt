package com.example.flutter_perposal_profile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
